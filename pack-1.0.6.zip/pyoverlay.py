"""طبقة تحديث الكود: تشغيل بايثون من مجلد بيانات قابل للتحديث (تحديثات بالكيلوبايت).

الفكرة: ننسخ ملفات .py المرفقة إلى <data>/py مرة واحدة، ونضع هذا المجلد أول sys.path،
فيصبح أي ملف نستبدله هناك هو الذي يعمل — بدون إعادة تثبيت APK.
"""

import os
import shutil
import sys

import vanta_paths

OVERLAY = vanta_paths.path("py")
MARK = os.path.join(OVERLAY, ".seeded")
VERSION_FILE = os.path.join(OVERLAY, ".version")


def _bundled_dir():
    return os.path.dirname(os.path.abspath(__file__))


def seed(force=False):
    """ينسخ المصادر المرفقة إلى مجلد التحديث (مرة واحدة)."""
    try:
        os.makedirs(OVERLAY, exist_ok=True)
        src_root = _bundled_dir()
        if os.path.abspath(src_root) == os.path.abspath(OVERLAY):
            return 0
        if os.path.exists(MARK) and not force:
            return 0
        n = 0
        for root, dirs, files in os.walk(src_root):
            dirs[:] = [d for d in dirs if d not in ("__pycache__", "templates", "sandbox", "uploads")]
            for fn in files:
                if not fn.endswith(".py"):
                    continue
                src = os.path.join(root, fn)
                rel = os.path.relpath(src, src_root)
                dst = os.path.join(OVERLAY, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                if not os.path.exists(dst) or force:
                    shutil.copyfile(src, dst)
                    n += 1
        with open(MARK, "w", encoding="utf-8") as f:
            f.write("seeded")
        return n
    except Exception:
        return 0


def activate():
    """يضع مجلد التحديث أول sys.path (يُستدعى قبل استيراد باقي الوحدات)."""
    try:
        seed()
        if os.path.isdir(OVERLAY) and OVERLAY not in sys.path:
            sys.path.insert(0, OVERLAY)
            return True
    except Exception:
        pass
    return False


def current_version():
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip() or "bundled"
    except Exception:
        return "bundled"


def set_version(v):
    try:
        with open(VERSION_FILE, "w", encoding="utf-8") as f:
            f.write(str(v or "pack"))
    except Exception:
        pass


def stats():
    n = 0
    try:
        for root, dirs, files in os.walk(OVERLAY):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            n += sum(1 for f in files if f.endswith(".py"))
    except Exception:
        pass
    return {"overlay": OVERLAY, "files": n, "version": current_version(),
            "active": bool(sys.path and sys.path[0] == OVERLAY)}
