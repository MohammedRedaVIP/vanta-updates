"""تحديثات صغيرة (كيلوبايت): تنزيل حزمة أكواد وتطبيقها على طبقة التحديث."""

import hashlib
import json
import os
import time
import urllib.request
import zipfile

import pyoverlay
import settings
import vanta_paths

BACKUP_DIR = vanta_paths.path("py-backups")
ALLOWED_EXT = (".py", ".txt", ".json", ".md")


def _get(url, timeout=60, max_bytes=8 * 1024 * 1024):
    req = urllib.request.Request(url, headers={"User-Agent": "VANTA-Updater/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(max_bytes)


def status():
    st = settings.load()
    s = pyoverlay.stats()
    s["update_url"] = st.get("update_url") or ""
    s["apk_version"] = "1.0.6"
    return s


def check(url=None):
    """يقرأ manifest (JSON) ويقارن الإصدار."""
    url = (url or settings.get("update_url") or "").strip()
    if not url:
        return {"ok": False, "error": "لا يوجد update_url — ضعه في الإعدادات المتقدمة"}
    try:
        raw = _get(url)
        man = json.loads(raw.decode("utf-8", "replace"))
    except Exception as e:
        return {"ok": False, "error": "تعذّر قراءة manifest: %s" % e}
    cur = pyoverlay.current_version()
    man["current"] = cur
    man["update_available"] = str(man.get("version") or "") != str(cur)
    man["ok"] = True
    return man


def _safe_extract(zpath):
    """يفك الحزمة إلى طبقة التحديث، مع نسخة احتياطية قبل الاستبدال."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S")
    bak = os.path.join(BACKUP_DIR, "backup-%s.zip" % ts)
    written, skipped = [], 0
    with zipfile.ZipFile(bak, "w", zipfile.ZIP_DEFLATED) as bz:
        for root, dirs, files in os.walk(pyoverlay.OVERLAY):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for fn in files:
                if not fn.endswith(".py"):
                    continue
                full = os.path.join(root, fn)
                bz.write(full, os.path.relpath(full, pyoverlay.OVERLAY))
    with zipfile.ZipFile(zpath) as z:
        for ent in z.infolist():
            name = ent.filename.replace("\\", "/").lstrip("/")
            if ent.is_dir() or ".." in name.split("/"):
                continue
            if not name.endswith(ALLOWED_EXT):
                skipped += 1
                continue
            if name.startswith("py/") or name.startswith("vanta-app/"):
                name = name.split("/", 1)[1] if name.count("/") > 0 else name
            target = os.path.join(pyoverlay.OVERLAY, name)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(ent) as src, open(target, "wb") as dst:
                dst.write(src.read())
            written.append(name)
    return written, skipped, bak


def apply(pack_url, sha256=None, version=None):
    """ينزّل الحزمة ويتحقق من البصمة ويطبّقها."""
    if not pack_url:
        return {"ok": False, "error": "لا يوجد رابط حزمة"}
    tmp = vanta_paths.path("update-pack.zip")
    try:
        data = _get(pack_url)
        if sha256:
            got = hashlib.sha256(data).hexdigest()
            if got.lower() != str(sha256).lower():
                return {"ok": False, "error": "بصمة SHA غير مطابقة — تم الإلغاء"}
        with open(tmp, "wb") as f:
            f.write(data)
        written, skipped, bak = _safe_extract(tmp)
        pyoverlay.set_version(version or time.strftime("pack-%Y%m%d-%H%M"))
        try:
            os.remove(tmp)
        except Exception:
            pass
        return {"ok": True, "files": len(written), "skipped": skipped,
                "backup": os.path.basename(bak), "size_kb": round(len(data) / 1024.0, 1),
                "need_restart": True,
                "message": "✅ طُبّق التحديث (%d ملف، %.1f ك.ب). أعد تشغيل التطبيق." % (
                    len(written), len(data) / 1024.0)}
    except Exception as e:
        return {"ok": False, "error": "فشل التطبيق: %s" % e}


def rollback():
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        items = sorted(x for x in os.listdir(BACKUP_DIR) if x.endswith(".zip"))
        if not items:
            return {"ok": False, "error": "لا نسخ احتياطية"}
        bak = os.path.join(BACKUP_DIR, items[-1])
        written, _, _ = _safe_extract(bak)
        pyoverlay.set_version("rollback")
        return {"ok": True, "message": "↩️ رجعنا النسخة السابقة (%d ملف). أعد تشغيل التطبيق." % len(written)}
    except Exception as e:
        return {"ok": False, "error": str(e)}
